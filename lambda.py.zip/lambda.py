def lambdaHandler(event, context):
    print('Hello World v1.0')
    return 'v1.0'